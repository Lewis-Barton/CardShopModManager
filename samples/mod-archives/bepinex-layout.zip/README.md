Layout sample.
