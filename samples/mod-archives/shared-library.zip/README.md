A dependency library.
